## About the connector
A minimal example connector for learning FortiSOAR connector structure. Returns simple greetings and messages.
<p>This document provides information about the Hello World Connector, which facilitates automated interactions, with a Hello World server using FortiSOAR&trade; playbooks. Add the Hello World Connector as a step in FortiSOAR&trade; playbooks and perform automated operations with Hello World.</p>

### Version information

Connector Version: 1.0.0


Authored By: Workshop Student

Certified: No
## Installing the connector
<p>From FortiSOAR&trade; 5.0.0 onwards, use the <strong>Connector Store</strong> to install the connector. For the detailed procedure to install a connector, click <a href="https://docs.fortinet.com/document/fortisoar/0.0.0/installing-a-connector/1/installing-a-connector" target="_top">here</a>.<br>You can also use the following <code>yum</code> command as a root user to install connectors from an SSH session:</p>
`yum install cyops-connector-hello-world`

## Prerequisites to configuring the connector
- You must have the URL of Hello World server to which you will connect and perform automated operations and credentials to access that server.
- The FortiSOAR&trade; server should have outbound connectivity to port 443 on the Hello World server.

## Minimum Permissions Required
- N/A

## Configuring the connector
For the procedure to configure a connector, click [here](https://docs.fortinet.com/document/fortisoar/0.0.0/configuring-a-connector/1/configuring-a-connector)
### Configuration parameters
<p>In FortiSOAR&trade;, on the Connectors page, click the <strong>Hello World</strong> connector row (if you are in the <strong>Grid</strong> view on the Connectors page) and in the <strong>Configurations&nbsp;</strong> tab enter the required configuration details:&nbsp;</p>
<table border=1><thead><tr><th>Parameter<br></th><th>Description<br></th></tr></thead><tbody><tr><td>Default Greeting<br></td><td><br>
</td></tr></tbody></table>

## Actions supported by the connector
The following automated operations can be included in playbooks and you can also use the annotations to access operations from FortiSOAR&trade; release 4.10.0 and onwards:
<table border=1><thead><tr><th>Function<br></th><th>Description<br></th><th>Annotation and Category<br></th></tr></thead><tbody><tr><td>Say Hello<br></td><td>Returns a simple greeting message using the configured greeting word and a name you provide.<br></td><td> <br/><br></td></tr>
<tr><td>Add Numbers<br></td><td>Adds two numbers together and returns the result. Demonstrates how to work with numeric parameters.<br></td><td> <br/><br></td></tr>
<tr><td>Reverse Text<br></td><td>Reverses a string of text and returns the result. Demonstrates simple string manipulation.<br></td><td> <br/>Investigation<br></td></tr>
</tbody></table>

### operation: Say Hello
#### Input parameters
<table border=1><thead><tr><th>Parameter<br></th><th>Description<br></th></tr></thead><tbody><tr><td>Name<br></td><td>The name to greet.<br>
</td></tr></tbody></table>

#### Output

 No output schema is available at this time.

### operation: Add Numbers
#### Input parameters
<table border=1><thead><tr><th>Parameter<br></th><th>Description<br></th></tr></thead><tbody><tr><td>Number A<br></td><td>The first number.<br>
</td></tr><tr><td>Number B<br></td><td>The second number.<br>
</td></tr></tbody></table>

#### Output

 No output schema is available at this time.

### operation: Reverse Text
#### Input parameters
<table border=1><thead><tr><th>Parameter<br></th><th>Description<br></th></tr></thead><tbody><tr><td>Input Text<br></td><td>The text to reverse.<br>
</td></tr></tbody></table>

#### Output

 No output schema is available at this time.

## Included playbooks
The `Sample - hello-world - 1.0.0` playbook collection comes bundled with the Hello World connector. These playbooks contain steps using which you can perform all supported actions. You can see bundled playbooks in the **Automation** > **Playbooks** section in FortiSOAR<sup>TM</sup> after importing the Hello World connector.

- Add Numbers
- Reverse Text
- Say Hello

**Note**: If you are planning to use any of the sample playbooks in your environment, ensure that you clone those playbooks and move them to a different collection, since the sample playbook collection gets deleted during connector upgrade and delete.
