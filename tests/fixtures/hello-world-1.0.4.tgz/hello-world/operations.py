from connectors.core.connector import ConnectorError, get_logger

logger = get_logger("hello-world")

def check_health(config):
    """
    Health check - verifies that the configuration is valid.
    In a real connector this would call an external API.
    Here we just confirm the default_greeting field is not empty.
    """
    greeting = config.get("default_greeting", "").strip()
    if not greeting:
        raise ConnectorError("Default Greeting cannot be empty.")
    return True


def say_hello(config, params):
    """
    Returns a greeting message.

    Uses the default_greeting from config and the name from params.
    Example output: {"message": "Hello, World!"}
    """
    greeting = config.get("default_greeting", "Hello")
    name = params.get("name", "World")
    message = f"{greeting}, {name}!"
    logger.debug(f"message:{message}")
    return {"message": message}


def add_numbers(config, params):
    """
    Adds two numbers and returns the result.

    Example output: {"number_a": 3, "number_b": 7, "result": 10}
    """
    number_a = params.get("number_a")
    number_b = params.get("number_b")

    if number_a is None or number_b is None:
        raise ConnectorError("Both Number A and Number B are required.")

    try:
        result = int(number_a) + int(number_b)
    except (ValueError, TypeError):
        raise ConnectorError("Number A and Number B must be valid integers.")

    return {
        "number_a": number_a,
        "number_b": number_b,
        "result": result
    }


def reverse_text(config, params):
    """
    Reverses a string of text.

    Example output: {"original": "hello", "reversed": "olleh"}
    """
    input_text = params.get("input_text", "")

    if not input_text:
        raise ConnectorError("Input Text is required.")

    return {
        "original": input_text,
        "reversed": input_text[::-1]
    }