from connectors.core.connector import Connector, ConnectorError
from .operations import check_health, say_hello, add_numbers, reverse_text

# Map operation API names (from info.json) to their Python functions
operations = {
    "say_hello": say_hello,
    "add_numbers": add_numbers,
    "reverse_text": reverse_text,
}


class HelloConnector(Connector):

    def execute(self, config, operation, params, **kwargs):
        """Called when FortiSOAR runs any operation on this connector."""
        action = operations.get(operation)
        if action:
            return action(config, params)
        raise ConnectorError(f"Unknown operation: {operation}")

    def check_health(self, config):
        """Called when FortiSOAR tests the connector configuration."""
        return check_health(config)